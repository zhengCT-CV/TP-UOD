MMDeploy deployment tutorial
********************************

.. toctree::
   :maxdepth: 1

   mmdeploy_guide.md
   mmdeploy_yolov5.md

EasyDeploy deployment tutorial
************************************

.. toctree::
   :maxdepth: 1

   easydeploy_guide.md

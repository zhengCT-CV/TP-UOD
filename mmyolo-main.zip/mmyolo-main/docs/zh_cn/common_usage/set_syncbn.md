# 开启和关闭 SyncBatchNorm

# Copyright (c) OpenMMLab. All rights reserved.
from .yolo_detector import YOLODetector

__all__ = ['YOLODetector']
